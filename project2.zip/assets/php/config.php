<?php

	$cd_host = "3306";
	$cd_dbname = "manofdjg_companydirectory";
	$cd_user = "manofdjg_manoj182";
	$cd_password = "thapa182";

?>
